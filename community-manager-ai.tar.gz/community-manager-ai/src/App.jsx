import React, { useState } from 'react';
import { Calendar, Instagram, Sparkles, TrendingUp, MessageCircle, Heart, Share2, Bookmark, Send, Clock, Edit3, RefreshCw, Download, Settings, ChevronLeft, ChevronRight, Zap, Target, Palette, Users, Check } from 'lucide-react';

const CommunityManagerSaaS = () => {
  // Estados principales
  const [step, setStep] = useState(0);
  const [activeTab, setActiveTab] = useState('generar');
  const [selectedContent, setSelectedContent] = useState(null);
  const [isGeneratingPosts, setIsGeneratingPosts] = useState(false);
  const [isGeneratingStories, setIsGeneratingStories] = useState(false);
  
  // Datos del negocio
  const [businessData, setBusinessData] = useState({
    name: '',
    industry: '',
    description: '',
    tone: '',
    primaryColor: '#0891b2',
    secondaryColor: '#f97316',
    audience: ''
  });

  // Contenido generado
  const [generatedPosts, setGeneratedPosts] = useState([]);
  const [generatedStories, setGeneratedStories] = useState([]);

  // Industrias disponibles
  const industries = [
    'Restaurante',
    'Retail',
    'Servicios',
    'Tecnología',
    'Salud',
    'Educación',
    'Otro'
  ];

  // Tonos de comunicación
  const tones = [
    { value: 'profesional', label: 'Profesional', icon: '👔', desc: 'Formal y experto' },
    { value: 'casual', label: 'Casual', icon: '😊', desc: 'Cercano y amigable' },
    { value: 'divertido', label: 'Divertido', icon: '🎉', desc: 'Creativo y entretenido' }
  ];

  // Función para generar posts personalizados
  const generatePosts = () => {
    setIsGeneratingPosts(true);
    
    setTimeout(() => {
      const posts = [
        // POST 1: Carrusel - 5 Beneficios
        {
          id: 1,
          type: 'carrusel',
          title: `5 Beneficios de ${businessData.name}`,
          copy: `✨ ¿Por qué elegir ${businessData.name}? Aquí te lo contamos:\n\n1️⃣ Calidad garantizada - Trabajamos con los más altos estándares\n2️⃣ Atención personalizada - Tu satisfacción es nuestra prioridad\n3️⃣ Experiencia comprobada - Años de excelencia en ${businessData.industry.toLowerCase()}\n4️⃣ Innovación constante - Siempre a la vanguardia\n5️⃣ Resultados reales - Clientes satisfechos nos respaldan\n\n💬 ¿Cuál de estos beneficios te motiva más? ¡Déjanos un comentario! 👇\n\n#${businessData.name.replace(/\s/g, '')} #${businessData.industry} #CalidadPremium`,
          visualIdea: 'Carrusel de 6 slides con diseño moderno y minimalista. Slide 1: Portada con título llamativo. Slides 2-6: Cada beneficio con icono ilustrativo y fondo degradado en colores de marca.',
          hashtags: ['#' + businessData.name.replace(/\s/g, ''), '#' + businessData.industry, '#CalidadPremium'],
          scheduledDate: new Date(2025, 9, 8)
        },
        
        // POST 2: Reel - Behind the Scenes
        {
          id: 2,
          type: 'reel',
          title: 'Un día en la vida de nuestro equipo',
          copy: `🎬 Así se ve un día típico en ${businessData.name} ✨\n\nDejamos que las cámaras capturen la magia detrás de cada detalle que hace especial tu experiencia con nosotros 💙\n\nDesliza para ver el proceso completo 👉\n\n¿Te gustaría más contenido así? ¡Síguenos para no perderte nada! 🔔\n\n#BehindTheScenes #${businessData.name.replace(/\s/g, '')} #${businessData.industry}Auténtico`,
          videoScript: `🎥 GUION DE VIDEO (30 segundos):\n\n0-3s: Toma aérea del espacio con música energética\n4-7s: Close-up del equipo preparando todo\n8-12s: Proceso de trabajo en tiempo rápido (timelapse)\n13-18s: Interacción con clientes (sonrisas genuinas)\n19-24s: Resultado final/producto terminado\n25-30s: Logo de ${businessData.name} con call-to-action`,
          visualIdea: 'Video vertical (9:16) con transiciones dinámicas, texto overlay con fuente bold, música de fondo trending en Reels.',
          hashtags: ['#BehindTheScenes', '#' + businessData.name.replace(/\s/g, ''), '#' + businessData.industry + 'Auténtico'],
          scheduledDate: new Date(2025, 9, 12)
        },
        
        // POST 3: Imagen - Tip del día
        {
          id: 3,
          type: 'imagen',
          title: 'Consejo de experto',
          copy: `💡 TIP DEL DÍA\n\n"${getTipByIndustry(businessData.industry)}"\n\nEn ${businessData.name} sabemos que los pequeños detalles marcan la diferencia ✨\n\n¿Ya conocías este consejo? ¡Guarda este post para tenerlo siempre a mano! 📌\n\nSíguenos para más tips exclusivos cada semana 👆\n\n#TipDelDia #${businessData.industry}Tips #${businessData.name.replace(/\s/g, '')}`,
          visualIdea: 'Quote card con fondo degradado en colores de marca, tipografía grande y legible, icono decorativo relacionado con el tip, logo de la marca en esquina inferior.',
          hashtags: ['#TipDelDia', '#' + businessData.industry + 'Tips', '#' + businessData.name.replace(/\s/g, '')],
          scheduledDate: new Date(2025, 9, 15)
        }
      ];
      
      setGeneratedPosts(posts);
      setIsGeneratingPosts(false);
    }, 2000);
  };

  // Función auxiliar para tips según industria
  const getTipByIndustry = (industry) => {
    const tips = {
      'Restaurante': 'La presentación del plato es tan importante como el sabor. Come primero con los ojos.',
      'Retail': 'La experiencia de compra comienza desde que el cliente ve tu escaparate.',
      'Servicios': 'La puntualidad y comunicación clara son la base de la confianza.',
      'Tecnología': 'La mejor tecnología es aquella que simplifica la vida del usuario.',
      'Salud': 'La prevención siempre será más efectiva que el tratamiento.',
      'Educación': 'El aprendizaje efectivo sucede cuando conectamos con la curiosidad natural.',
      'Otro': 'La excelencia no es un acto, sino un hábito.'
    };
    return tips[industry] || tips['Otro'];
  };

  // Función para generar stories personalizadas
  const generateStories = () => {
    setIsGeneratingStories(true);
    
    setTimeout(() => {
      const stories = [
        // STORY 1: Pregunta interactiva
        {
          id: 1,
          type: 'pregunta',
          title: 'Pregunta del día',
          copy: `🤔 PREGUNTA PARA TI\n\n¿Qué es lo que más valoras de ${businessData.name}?\n\n📩 Responde con la caja de preguntas\n\nTus respuestas nos ayudan a mejorar cada día ✨`,
          visualIdea: 'Fondo con gradiente de colores de marca, texto centrado con emoji grande arriba, sticker de caja de preguntas de Instagram.',
          scheduledDate: new Date(2025, 9, 9)
        },
        
        // STORY 2: Encuesta
        {
          id: 2,
          type: 'encuesta',
          title: 'Encuesta rápida',
          copy: `📊 AYÚDANOS A DECIDIR\n\n¿Qué contenido quieres ver más?\n\nA) Tips y consejos\nB) Behind the scenes\n\n¡Vota ahora! 👆`,
          visualIdea: 'Fondo sólido en color primario, texto en blanco, sticker de encuesta de Instagram con las dos opciones.',
          scheduledDate: new Date(2025, 9, 10)
        },
        
        // STORY 3: Testimonio
        {
          id: 3,
          type: 'testimonio',
          title: 'Testimonio de cliente',
          copy: `⭐⭐⭐⭐⭐\n\n"Increíble experiencia con ${businessData.name}. Superaron todas mis expectativas."\n\n- Cliente satisfecho\n\n💙 Gracias por confiar en nosotros`,
          visualIdea: 'Fondo blanco o claro, quote en tipografía elegante, estrellas doradas arriba, foto sutil del cliente (o avatar) abajo.',
          scheduledDate: new Date(2025, 9, 11)
        },
        
        // STORY 4: Promoción
        {
          id: 4,
          type: 'promocion',
          title: 'Oferta especial',
          copy: `🔥 OFERTA EXCLUSIVA\n\n20% OFF\nSolo por hoy\n\n✨ Menciona esta story al visitar ${businessData.name}\n\n⏰ Válido hasta las 23:59\n\n¡No te lo pierdas! 🎁`,
          visualIdea: 'Fondo llamativo con gradiente naranja-rojo, badge de descuento grande, cuenta regresiva animada, botón de CTA "Desliza arriba".',
          scheduledDate: new Date(2025, 9, 13)
        }
      ];
      
      setGeneratedStories(stories);
      setIsGeneratingStories(false);
    }, 2000);
  };

  // Navegación del onboarding
  const nextStep = () => {
    if (step === 0 && !businessData.name) {
      alert('Por favor ingresa el nombre de tu negocio');
      return;
    }
    if (step === 0 && !businessData.industry) {
      alert('Por favor selecciona una industria');
      return;
    }
    if (step === 1 && !businessData.tone) {
      alert('Por favor selecciona un tono de comunicación');
      return;
    }
    
    if (step < 2) {
      setStep(step + 1);
    } else {
      setStep('dashboard');
    }
  };

  const prevStep = () => {
    if (step > 0) {
      setStep(step - 1);
    }
  };

  // Componente de onboarding
  const OnboardingStep = () => {
    if (step === 0) {
      return (
        <div className="space-y-6">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full mb-4">
              <Sparkles className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Información básica</h2>
            <p className="text-gray-600">Cuéntanos sobre tu negocio</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Nombre del negocio *
            </label>
            <input
              type="text"
              value={businessData.name}
              onChange={(e) => setBusinessData({...businessData, name: e.target.value})}
              placeholder="Ej: Café Aroma"
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Industria/Sector *
            </label>
            <select
              value={businessData.industry}
              onChange={(e) => setBusinessData({...businessData, industry: e.target.value})}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
            >
              <option value="">Selecciona una opción</option>
              {industries.map(ind => (
                <option key={ind} value={ind}>{ind}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Descripción breve (opcional)
            </label>
            <textarea
              value={businessData.description}
              onChange={(e) => setBusinessData({...businessData, description: e.target.value})}
              placeholder="Describe tu negocio en pocas palabras..."
              rows="3"
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
            />
          </div>
        </div>
      );
    }

    if (step === 1) {
      return (
        <div className="space-y-6">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full mb-4">
              <Palette className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Identidad de marca</h2>
            <p className="text-gray-600">Define el estilo de tu comunicación</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Tono de comunicación *
            </label>
            <div className="grid grid-cols-1 gap-3">
              {tones.map(tone => (
                <button
                  key={tone.value}
                  onClick={() => setBusinessData({...businessData, tone: tone.value})}
                  className={`p-4 rounded-lg border-2 transition-all text-left ${
                    businessData.tone === tone.value
                      ? 'border-cyan-500 bg-cyan-50'
                      : 'border-gray-200 hover:border-cyan-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <span className="text-2xl">{tone.icon}</span>
                      <div>
                        <div className="font-semibold text-gray-900">{tone.label}</div>
                        <div className="text-sm text-gray-600">{tone.desc}</div>
                      </div>
                    </div>
                    {businessData.tone === tone.value && (
                      <Check className="w-5 h-5 text-cyan-500" />
                    )}
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Color principal
              </label>
              <div className="flex space-x-2">
                <input
                  type="color"
                  value={businessData.primaryColor}
                  onChange={(e) => setBusinessData({...businessData, primaryColor: e.target.value})}
                  className="w-16 h-12 rounded border border-gray-300 cursor-pointer"
                />
                <input
                  type="text"
                  value={businessData.primaryColor}
                  onChange={(e) => setBusinessData({...businessData, primaryColor: e.target.value})}
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-lg"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Color secundario
              </label>
              <div className="flex space-x-2">
                <input
                  type="color"
                  value={businessData.secondaryColor}
                  onChange={(e) => setBusinessData({...businessData, secondaryColor: e.target.value})}
                  className="w-16 h-12 rounded border border-gray-300 cursor-pointer"
                />
                <input
                  type="text"
                  value={businessData.secondaryColor}
                  onChange={(e) => setBusinessData({...businessData, secondaryColor: e.target.value})}
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-lg"
                />
              </div>
            </div>
          </div>
        </div>
      );
    }

    if (step === 2) {
      return (
        <div className="space-y-6">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-pink-500 to-orange-500 rounded-full mb-4">
              <Users className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Tu audiencia</h2>
            <p className="text-gray-600">¿A quién quieres llegar?</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Descripción de audiencia objetivo (opcional)
            </label>
            <textarea
              value={businessData.audience}
              onChange={(e) => setBusinessData({...businessData, audience: e.target.value})}
              placeholder="Ej: Jóvenes profesionales de 25-35 años interesados en estilo de vida saludable..."
              rows="4"
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
            />
          </div>

          <div className="bg-gradient-to-r from-cyan-50 to-blue-50 rounded-lg p-6 border border-cyan-200">
            <h3 className="font-semibold text-gray-900 mb-4">Resumen de tu configuración</h3>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Negocio:</span>
                <span className="font-medium text-gray-900">{businessData.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Industria:</span>
                <span className="font-medium text-gray-900">{businessData.industry}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Tono:</span>
                <span className="font-medium text-gray-900 capitalize">{businessData.tone}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Colores:</span>
                <div className="flex space-x-2">
                  <div 
                    className="w-6 h-6 rounded border border-gray-300" 
                    style={{backgroundColor: businessData.primaryColor}}
                  />
                  <div 
                    className="w-6 h-6 rounded border border-gray-300" 
                    style={{backgroundColor: businessData.secondaryColor}}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      );
    }
  };

  // Componente del Dashboard
  const Dashboard = () => {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header Sticky */}
        <div className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm">
          <div className="max-w-7xl mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div 
                  className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-lg"
                  style={{background: `linear-gradient(135deg, ${businessData.primaryColor}, ${businessData.secondaryColor})`}}
                >
                  {businessData.name.charAt(0).toUpperCase()}
                </div>
                <div>
                  <h1 className="font-bold text-gray-900 text-lg">{businessData.name}</h1>
                  <p className="text-xs text-gray-500">{businessData.industry}</p>
                </div>
              </div>
              <button
                onClick={() => setStep(0)}
                className="p-2 hover:bg-gray-100 rounded-lg transition"
              >
                <Settings className="w-5 h-5 text-gray-600" />
              </button>
            </div>
          </div>

          {/* Navegación por pestañas */}
          <div className="max-w-7xl mx-auto px-4">
            <div className="flex space-x-1 overflow-x-auto pb-2">
              <button
                onClick={() => setActiveTab('generar')}
                className={`px-4 py-2 rounded-lg font-medium text-sm whitespace-nowrap transition ${
                  activeTab === 'generar'
                    ? 'bg-cyan-500 text-white'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <Sparkles className="w-4 h-4 inline mr-1" />
                Generar
              </button>
              <button
                onClick={() => setActiveTab('calendario')}
                className={`px-4 py-2 rounded-lg font-medium text-sm whitespace-nowrap transition ${
                  activeTab === 'calendario'
                    ? 'bg-cyan-500 text-white'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <Calendar className="w-4 h-4 inline mr-1" />
                Calendario
              </button>
              <button
                onClick={() => setActiveTab('preview')}
                className={`px-4 py-2 rounded-lg font-medium text-sm whitespace-nowrap transition ${
                  activeTab === 'preview'
                    ? 'bg-cyan-500 text-white'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <Instagram className="w-4 h-4 inline mr-1" />
                Vista Previa
              </button>
            </div>
          </div>
        </div>

        {/* Contenido según pestaña activa */}
        <div className="max-w-7xl mx-auto px-4 py-6">
          {activeTab === 'generar' && <GeneratorTab />}
          {activeTab === 'calendario' && <CalendarTab />}
          {activeTab === 'preview' && <PreviewTab />}
        </div>
      </div>
    );
  };

  // Pestaña Generar
  const GeneratorTab = () => {
    return (
      <div className="space-y-6">
        {/* Tarjetas de generación */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Card Posts */}
          <div className="bg-white rounded-xl shadow-md overflow-hidden border border-gray-200 hover:shadow-lg transition">
            <div 
              className="h-32 flex items-center justify-center"
              style={{background: `linear-gradient(135deg, ${businessData.primaryColor}, ${businessData.secondaryColor})`}}
            >
              <Instagram className="w-16 h-16 text-white opacity-90" />
            </div>
            <div className="p-6">
              <h3 className="text-xl font-bold text-gray-900 mb-2">Posts para Feed</h3>
              <p className="text-gray-600 text-sm mb-4">Carruseles, Reels e Imágenes</p>
              
              <div className="space-y-2 mb-6">
                <div className="flex items-start space-x-2 text-sm text-gray-700">
                  <Check className="w-4 h-4 text-cyan-500 mt-0.5 flex-shrink-0" />
                  <span>Ideas de publicación personalizadas</span>
                </div>
                <div className="flex items-start space-x-2 text-sm text-gray-700">
                  <Check className="w-4 h-4 text-cyan-500 mt-0.5 flex-shrink-0" />
                  <span>Copys optimizados con emojis</span>
                </div>
                <div className="flex items-start space-x-2 text-sm text-gray-700">
                  <Check className="w-4 h-4 text-cyan-500 mt-0.5 flex-shrink-0" />
                  <span>Hashtags relevantes</span>
                </div>
                <div className="flex items-start space-x-2 text-sm text-gray-700">
                  <Check className="w-4 h-4 text-cyan-500 mt-0.5 flex-shrink-0" />
                  <span>Sugerencias visuales</span>
                </div>
              </div>

              <button
                onClick={generatePosts}
                disabled={isGeneratingPosts}
                className="w-full py-3 rounded-lg font-semibold text-white bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
              >
                {isGeneratingPosts ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Generando...</span>
                  </>
                ) : (
                  <>
                    <Zap className="w-5 h-5" />
                    <span>Generar Posts</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Card Stories */}
          <div className="bg-white rounded-xl shadow-md overflow-hidden border border-gray-200 hover:shadow-lg transition">
            <div className="h-32 bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center">
              <MessageCircle className="w-16 h-16 text-white opacity-90" />
            </div>
            <div className="p-6">
              <h3 className="text-xl font-bold text-gray-900 mb-2">Stories</h3>
              <p className="text-gray-600 text-sm mb-4">Contenido efímero impactante</p>
              
              <div className="space-y-2 mb-6">
                <div className="flex items-start space-x-2 text-sm text-gray-700">
                  <Check className="w-4 h-4 text-purple-500 mt-0.5 flex-shrink-0" />
                  <span>Preguntas interactivas</span>
                </div>
                <div className="flex items-start space-x-2 text-sm text-gray-700">
                  <Check className="w-4 h-4 text-purple-500 mt-0.5 flex-shrink-0" />
                  <span>Encuestas de engagement</span>
                </div>
                <div className="flex items-start space-x-2 text-sm text-gray-700">
                  <Check className="w-4 h-4 text-purple-500 mt-0.5 flex-shrink-0" />
                  <span>Testimonios y quotes</span>
                </div>
                <div className="flex items-start space-x-2 text-sm text-gray-700">
                  <Check className="w-4 h-4 text-purple-500 mt-0.5 flex-shrink-0" />
                  <span>Promociones llamativas</span>
                </div>
              </div>

              <button
                onClick={generateStories}
                disabled={isGeneratingStories}
                className="w-full py-3 rounded-lg font-semibold text-white bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
              >
                {isGeneratingStories ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Generando...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-5 h-5" />
                    <span>Generar Stories</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Grid de contenido generado */}
        {(generatedPosts.length > 0 || generatedStories.length > 0) && (
          <div>
            <h3 className="text-lg font-bold text-gray-900 mb-4">Contenido Generado</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {generatedPosts.map(post => (
                <div
                  key={post.id}
                  onClick={() => {
                    setSelectedContent(post);
                    setActiveTab('preview');
                  }}
                  className="bg-white rounded-lg shadow border border-gray-200 p-4 cursor-pointer hover:shadow-md hover:border-cyan-300 transition"
                >
                  <div className="flex items-center space-x-2 mb-2">
                    <div className="px-2 py-1 bg-cyan-100 text-cyan-700 text-xs font-medium rounded">
                      {post.type}
                    </div>
                  </div>
                  <h4 className="font-semibold text-gray-900 mb-2 line-clamp-1">{post.title}</h4>
                  <p className="text-sm text-gray-600 line-clamp-2">{post.copy}</p>
                </div>
              ))}
              
              {generatedStories.map(story => (
                <div
                  key={story.id}
                  onClick={() => {
                    setSelectedContent(story);
                    setActiveTab('preview');
                  }}
                  className="bg-white rounded-lg shadow border border-gray-200 p-4 cursor-pointer hover:shadow-md hover:border-purple-300 transition"
                >
                  <div className="flex items-center space-x-2 mb-2">
                    <div className="px-2 py-1 bg-purple-100 text-purple-700 text-xs font-medium rounded">
                      story
                    </div>
                  </div>
                  <h4 className="font-semibold text-gray-900 mb-2 line-clamp-1">{story.title}</h4>
                  <p className="text-sm text-gray-600 line-clamp-2">{story.copy}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  };

  // Pestaña Calendario
  const CalendarTab = () => {
    const currentMonth = 9; // Octubre (0-indexed)
    const currentYear = 2025;
    const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
    const firstDayOfMonth = new Date(currentYear, currentMonth, 1).getDay();
    
    const allContent = [...generatedPosts, ...generatedStories];
    
    const hasContentOnDay = (day) => {
      return allContent.some(content => {
        if (!content.scheduledDate) return false;
        const contentDate = new Date(content.scheduledDate);
        return contentDate.getDate() === day && 
               contentDate.getMonth() === currentMonth &&
               contentDate.getFullYear() === currentYear;
      });
    };

    const weekDays = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
    const days = [];
    
    // Días vacíos al inicio
    for (let i = 0; i < firstDayOfMonth; i++) {
      days.push(null);
    }
    
    // Días del mes
    for (let i = 1; i <= daysInMonth; i++) {
      days.push(i);
    }

    return (
      <div className="bg-white rounded-xl shadow-md p-6 border border-gray-200">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-gray-900">Octubre 2025</h2>
          <div className="flex space-x-2">
            <button className="p-2 hover:bg-gray-100 rounded-lg transition">
              <ChevronLeft className="w-5 h-5 text-gray-600" />
            </button>
            <button className="p-2 hover:bg-gray-100 rounded-lg transition">
              <ChevronRight className="w-5 h-5 text-gray-600" />
            </button>
          </div>
        </div>

        {/* Grid del calendario */}
        <div className="grid grid-cols-7 gap-2">
          {/* Headers de días */}
          {weekDays.map(day => (
            <div key={day} className="text-center text-xs font-semibold text-gray-600 py-2">
              {day}
            </div>
          ))}
          
          {/* Días del mes */}
          {days.map((day, index) => (
            <div
              key={index}
              className={`aspect-square flex flex-col items-center justify-center rounded-lg border transition ${
                day === null
                  ? 'border-transparent'
                  : day === 5
                  ? 'border-cyan-500 bg-cyan-50'
                  : 'border-gray-200 hover:border-cyan-300 hover:bg-gray-50'
              }`}
            >
              {day !== null && (
                <>
                  <span className={`text-sm font-medium ${day === 5 ? 'text-cyan-700' : 'text-gray-900'}`}>
                    {day}
                  </span>
                  {hasContentOnDay(day) && (
                    <div className="flex space-x-1 mt-1">
                      <div className="w-1.5 h-1.5 bg-cyan-500 rounded-full" />
                    </div>
                  )}
                </>
              )}
            </div>
          ))}
        </div>

        {allContent.length > 0 && (
          <div className="mt-6 pt-6 border-t border-gray-200">
            <h3 className="text-sm font-semibold text-gray-900 mb-3">Próximas publicaciones</h3>
            <div className="space-y-2">
              {allContent.slice(0, 3).map(content => (
                <div key={content.id} className="flex items-center space-x-3 text-sm">
                  <div className="w-2 h-2 bg-cyan-500 rounded-full flex-shrink-0" />
                  <span className="text-gray-600">
                    {content.scheduledDate && new Date(content.scheduledDate).getDate()} Oct
                  </span>
                  <span className="text-gray-900 font-medium truncate">{content.title}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  };

  // Pestaña Vista Previa
  const PreviewTab = () => {
    if (!selectedContent && generatedPosts.length === 0 && generatedStories.length === 0) {
      return (
        <div className="text-center py-12">
          <Instagram className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">No hay contenido seleccionado</h3>
          <p className="text-gray-600 mb-6">Genera contenido primero para ver la vista previa</p>
          <button
            onClick={() => setActiveTab('generar')}
            className="px-6 py-3 bg-cyan-500 text-white rounded-lg hover:bg-cyan-600 transition"
          >
            Ir a Generar
          </button>
        </div>
      );
    }

    const content = selectedContent || generatedPosts[0] || generatedStories[0];
    const isStory = content.type === 'pregunta' || content.type === 'encuesta' || 
                    content.type === 'testimonio' || content.type === 'promocion';

    return (
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Preview estilo Instagram */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden border border-gray-200">
          <div className="p-4 border-b border-gray-200">
            <h3 className="font-semibold text-gray-900 mb-4">Vista Previa</h3>
            
            {/* Post Header */}
            <div className="flex items-center space-x-3 mb-4">
              <div 
                className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold"
                style={{backgroundColor: businessData.primaryColor}}
              >
                {businessData.name.charAt(0).toUpperCase()}
              </div>
              <div className="flex-1">
                <div className="font-semibold text-sm text-gray-900">{businessData.name}</div>
                <div className="text-xs text-gray-500">Hace 2 horas</div>
              </div>
            </div>

            {/* Post Image/Story */}
            <div 
              className={`${isStory ? 'aspect-[9/16]' : 'aspect-square'} rounded-lg flex flex-col items-center justify-center p-8 text-white relative overflow-hidden`}
              style={{
                background: `linear-gradient(135deg, ${businessData.primaryColor}, ${businessData.secondaryColor})`
              }}
            >
              <div className="absolute inset-0 opacity-10" 
                   style={{backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '20px 20px'}}
              />
              <div className="relative z-10 text-center">
                {content.type === 'carrusel' && <Instagram className="w-16 h-16 mx-auto mb-4 opacity-90" />}
                {content.type === 'reel' && <TrendingUp className="w-16 h-16 mx-auto mb-4 opacity-90" />}
                {content.type === 'imagen' && <Target className="w-16 h-16 mx-auto mb-4 opacity-90" />}
                {isStory && <MessageCircle className="w-16 h-16 mx-auto mb-4 opacity-90" />}
                <div className="text-sm font-medium opacity-90">{content.visualIdea?.substring(0, 60)}...</div>
              </div>
            </div>

            {/* Post Actions (solo para posts, no stories) */}
            {!isStory && (
              <>
                <div className="flex items-center justify-between py-3">
                  <div className="flex space-x-4">
                    <Heart className="w-6 h-6 text-gray-700 cursor-pointer hover:text-red-500 transition" />
                    <MessageCircle className="w-6 h-6 text-gray-700 cursor-pointer hover:text-cyan-500 transition" />
                    <Send className="w-6 h-6 text-gray-700 cursor-pointer hover:text-cyan-500 transition" />
                  </div>
                  <Bookmark className="w-6 h-6 text-gray-700 cursor-pointer hover:text-cyan-500 transition" />
                </div>

                {/* Caption */}
                <div className="text-sm">
                  <span className="font-semibold text-gray-900">{businessData.name}</span>
                  <span className="text-gray-700 ml-2 whitespace-pre-line">{content.copy}</span>
                </div>

                {/* Hashtags */}
                {content.hashtags && (
                  <div className="mt-2 flex flex-wrap gap-2">
                    {content.hashtags.map((tag, idx) => (
                      <span key={idx} className="text-sm text-cyan-600 cursor-pointer hover:underline">
                        {tag}
                      </span>
                    ))}
                  </div>
                )}
              </>
            )}

            {/* Story Content */}
            {isStory && (
              <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-700 whitespace-pre-line">{content.copy}</p>
              </div>
            )}
          </div>
        </div>

        {/* Panel de detalles */}
        <div className="space-y-6">
          {/* Detalles del contenido */}
          <div className="bg-white rounded-xl shadow-md p-6 border border-gray-200">
            <h3 className="font-semibold text-gray-900 mb-4">Detalles</h3>
            
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-700">Tipo de contenido</label>
                <div className="mt-1 px-3 py-2 bg-gray-50 rounded-lg text-sm text-gray-900 capitalize">
                  {content.type}
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700">Título</label>
                <div className="mt-1 px-3 py-2 bg-gray-50 rounded-lg text-sm text-gray-900">
                  {content.title}
                </div>
              </div>

              {content.videoScript && (
                <div>
                  <label className="text-sm font-medium text-gray-700">Guion de video</label>
                  <div className="mt-1 px-3 py-2 bg-gray-50 rounded-lg text-sm text-gray-700 whitespace-pre-line max-h-48 overflow-y-auto">
                    {content.videoScript}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Acciones */}
          <div className="bg-white rounded-xl shadow-md p-6 border border-gray-200">
            <h3 className="font-semibold text-gray-900 mb-4">Acciones</h3>
            
            <div className="space-y-3">
              <button className="w-full py-3 px-4 bg-gradient-to-r from-cyan-500 to-blue-500 text-white rounded-lg hover:from-cyan-600 hover:to-blue-600 transition flex items-center justify-center space-x-2">
                <Download className="w-5 h-5" />
                <span>Descargar contenido</span>
              </button>

              <button className="w-full py-3 px-4 bg-white border-2 border-gray-300 text-gray-700 rounded-lg hover:border-cyan-500 hover:text-cyan-600 transition flex items-center justify-center space-x-2">
                <Edit3 className="w-5 h-5" />
                <span>Editar texto</span>
              </button>

              <button 
                onClick={() => {
                  if (content.type === 'carrusel' || content.type === 'reel' || content.type === 'imagen') {
                    generatePosts();
                  } else {
                    generateStories();
                  }
                }}
                className="w-full py-3 px-4 bg-white border-2 border-gray-300 text-gray-700 rounded-lg hover:border-purple-500 hover:text-purple-600 transition flex items-center justify-center space-x-2"
              >
                <RefreshCw className="w-5 h-5" />
                <span>Regenerar con IA</span>
              </button>
            </div>
          </div>

          {/* Sugerencia de IA */}
          <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl p-6 border border-purple-200">
            <div className="flex items-start space-x-3">
              <div className="flex-shrink-0 w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                <Clock className="w-5 h-5 text-white" />
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">💡 Tip de publicación</h4>
                <p className="text-sm text-gray-700">
                  {isStory 
                    ? 'Los mejores horarios para publicar Stories son de 9-11 AM y 7-9 PM cuando tu audiencia está más activa.'
                    : content.type === 'reel'
                    ? 'Los Reels tienen mayor alcance entre las 6-9 PM. Publica cuando tu audiencia sale del trabajo.'
                    : 'Los posts de feed funcionan mejor entre 11 AM - 1 PM y 7-9 PM en días laborales.'
                  }
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // Render principal
  if (step === 'dashboard') {
    return <Dashboard />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 via-blue-50 to-purple-50 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-700">
              Paso {step + 1} de 3
            </span>
            <span className="text-sm text-gray-500">
              {Math.round(((step + 1) / 3) * 100)}%
            </span>
          </div>
          <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 transition-all duration-300"
              style={{width: `${((step + 1) / 3) * 100}%`}}
            />
          </div>
        </div>

        {/* Card del onboarding */}
        <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-200">
          <OnboardingStep />

          {/* Botones de navegación */}
          <div className="flex space-x-4 mt-8">
            {step > 0 && (
              <button
                onClick={prevStep}
                className="flex-1 py-3 px-6 border-2 border-gray-300 text-gray-700 rounded-lg hover:border-cyan-500 hover:text-cyan-600 transition font-medium"
              >
                Atrás
              </button>
            )}
            <button
              onClick={nextStep}
              className={`${step === 0 ? 'w-full' : 'flex-1'} py-3 px-6 bg-gradient-to-r from-cyan-500 to-blue-500 text-white rounded-lg hover:from-cyan-600 hover:to-blue-600 transition font-semibold shadow-md hover:shadow-lg`}
            >
              {step === 2 ? '¡Comenzar! 🚀' : 'Continuar'}
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-8 text-center text-sm text-gray-600">
          <p>Powered by ✨ IA Community Manager</p>
        </div>
      </div>
    </div>
  );
};

export default CommunityManagerSaaS;